#dog
noun = input("Type in the noun: ")
print(noun)

#jump
verb = input("Type in a verb: ")
print(verb)

#happy
adjective = input("Type in an adjective: ")
print(adjective)

print("Once a " + adjective + " " + noun + " ," "decided to " + verb + " over the fence")